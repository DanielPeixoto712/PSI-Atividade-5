<ul>
<?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<a href="<?php echo e(route('livros.show', ['id'=>$livro->id_livro])); ?>"></a>
	<?php echo e($livro->titulo); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($livros->render()); ?>


<?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/livros/index.blade.php ENDPATH**/ ?>
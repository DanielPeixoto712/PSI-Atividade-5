ID:<?php echo e($autor->id_autor); ?><br>
Nome:<?php echo e($autor->nome); ?><br>
Nacionalidade:<?php echo e($autor->nacionalidade); ?>


<?php $__currentLoopData = $autor->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($livro->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\PSI\Atividade-4\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>